const CHUNK_SIZE = 192 * 1024;

function toBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let index = 0; index < bytes.length; index += 8192) {
    binary += String.fromCharCode(...bytes.subarray(index, index + 8192));
  }
  return btoa(binary);
}

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'wc-video-fetch') return;

  port.onMessage.addListener(async (message) => {
    if (message.type !== 'fetch-video') return;
    const { requestId, url } = message;

    try {
      const target = new URL(url);
      if (!['http:', 'https:'].includes(target.protocol)) {
        throw new Error('仅支持 HTTP 或 HTTPS 视频 URL');
      }

      const response = await fetch(target.href, { cache: 'no-store', credentials: 'omit' });
      if (!response.ok) throw new Error(`视频下载失败（HTTP ${response.status}）`);
      if (!response.body) throw new Error('浏览器不支持读取该视频响应');

      port.postMessage({
        type: 'video-start',
        requestId,
        mimeType: response.headers.get('content-type') || 'video/mp4',
        contentLength: Number(response.headers.get('content-length')) || 0
      });

      const reader = response.body.getReader();
      let pending = new Uint8Array(0);
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        const merged = new Uint8Array(pending.length + value.length);
        merged.set(pending);
        merged.set(value, pending.length);
        let offset = 0;
        while (merged.length - offset >= CHUNK_SIZE) {
          port.postMessage({ type: 'video-chunk', requestId, chunk: toBase64(merged.slice(offset, offset + CHUNK_SIZE).buffer) });
          offset += CHUNK_SIZE;
        }
        pending = merged.slice(offset);
      }
      if (pending.length) {
        port.postMessage({ type: 'video-chunk', requestId, chunk: toBase64(pending.buffer) });
      }
      port.postMessage({ type: 'video-complete', requestId });
    } catch (error) {
      port.postMessage({ type: 'video-error', requestId, message: error.message || '扩展下载失败' });
    }
  });
});
