document.documentElement.dataset.wcVideoExtension = 'ready';

function base64ToBuffer(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
  return bytes.buffer;
}

window.addEventListener('message', (event) => {
  if (event.source !== window || event.origin !== 'https://wc.getoneapi.com') return;
  const message = event.data;
  if (message?.channel === 'wc-video-decrypt' && message.type === 'fetch-video') {
    // A dedicated port per request prevents a retired service worker connection
    // from blocking the next URL decryption attempt.
    const port = chrome.runtime.connect({ name: 'wc-video-fetch' });

    port.onMessage.addListener((response) => {
      if (response?.requestId !== message.requestId) return;
      const payload = {
        channel: 'wc-video-decrypt',
        type: response.type,
        requestId: response.requestId,
        mimeType: response.mimeType,
        contentLength: response.contentLength,
        message: response.message
      };
      if (response.chunk) payload.chunk = base64ToBuffer(response.chunk);
      window.postMessage(payload, 'https://wc.getoneapi.com');

      if (response.type === 'video-complete' || response.type === 'video-error') {
        port.disconnect();
      }
    });

    port.onDisconnect.addListener(() => {
      if (!chrome.runtime.lastError) return;
      window.postMessage({
        channel: 'wc-video-decrypt',
        type: 'video-error',
        requestId: message.requestId,
        message: chrome.runtime.lastError.message
      }, 'https://wc.getoneapi.com');
    });

    port.postMessage({ type: 'fetch-video', requestId: message.requestId, url: message.url });
  }
});
