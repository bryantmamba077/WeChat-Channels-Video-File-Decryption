# WC 视频 URL 解密助手

这是一个 Chrome Manifest V3 扩展，用于解决 `https://wc.getoneapi.com` 在 URL 解密模式下读取第三方视频时遇到的 CORS 限制。

页面常规请求被 CORS 拦截时，扩展会在后台读取视频，并按小块传回页面内存供解密；不会保存视频到磁盘。扩展桥接脚本仅注入 `wc.getoneapi.com`。

## 安装

1. 在 Chrome 地址栏打开 `chrome://extensions`。
2. 打开右上角的“开发者模式”。
3. 点击“加载已解压的扩展程序”。
4. 选择本目录：`wc-assistant`。
5. 在扩展管理页点击扩展的“重新加载”按钮（更新代码后必须执行）。
6. 刷新 `https://wc.getoneapi.com`，在“输入加密视频 URL”模式中重试。

## 权限说明

扩展需要匹配 HTTP/HTTPS 视频地址的权限，才能读取用户输入的视频 URL；页面桥接则被限定为 `wc.getoneapi.com`。扩展不会把视频保存到本地，也不向其他服务上传数据。

请仅在信任该站及所输入视频 URL 的情况下启用。若不再需要，可在 Chrome 扩展管理页关闭或删除本扩展。
